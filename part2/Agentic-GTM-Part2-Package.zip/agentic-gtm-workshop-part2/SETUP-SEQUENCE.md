# Part 2 setup order

1. Reopen or finish the actual Part 1 company context, two account pages and saved page skill.
2. Prepare private configuration, exact sender and permitted countries. Run the supplied init once. Preserve existing history and grants.
3. Connect and read back the actual Google sender and calendar.
4. Save the ZeroBounce key privately and read its balance. Prepare ten targets and actual buyer evidence before class.
5. In class refresh current exclusions, inspect source facts and validate exact addresses with paid-call approval.
6. Review eleven exact messages, approve the pilot, send one owned test and verify its exact Gmail Sent match. Release only the original approved eligible prospect keys.
7. Read original results, save the email skill and leave sending paused. Unknown outcomes are read again, never submitted again.
