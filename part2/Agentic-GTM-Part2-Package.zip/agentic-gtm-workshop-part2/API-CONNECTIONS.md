# Part 2 connections

Open PREP.html for the exact account screens and complete connection prompts. Google uses your own desktop OAuth client JSON and browser consent, not a Gmail API key. ZeroBounce uses one key saved by save-api-key.py at a hidden terminal prompt. No model API key is required.

Private configuration: ~/.local/share/agentic-gtm/workshop-private/config.json. Provider keys: keys/PROVIDER.key. Keep these files outside the workshop project and company-motion/. Private folder mode 0700, file mode 0600.

Use your actual sender, calendar and credit balance to prove the connection. Use an existing CRM/export or one approved finder for buyer sources. Instantly/Apollo contact exports are inputs; this starter sends through Gmail. Paid research and exact message release need separate owner approval.
