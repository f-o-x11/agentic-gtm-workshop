# Agentic GTM Part 2

Open PREP.html first. Reuse the company-motion folder and code from Part 1. Do not overwrite a working database or existing private configuration with this empty starter. For a new project, use the catch-up prompt before class.

During class keep Zoom and Participant-Booklet.html open. All prompts are embedded. Commands run from code/. Company files, skills and results live in company-motion/. Credentials and filled configuration stay outside both directories.

The program has 20 files and an empty database template. Your local agent researches and writes; the program checks and sends only exact approved actions. Live email uses your Google account and real validation results. A stored key is not approval to send.

Core: five chapters, 95 minutes. Extra practice: 15 minutes. Help: 10 minutes. External actions, other channels and scheduling stay paused until their exact separate review.
